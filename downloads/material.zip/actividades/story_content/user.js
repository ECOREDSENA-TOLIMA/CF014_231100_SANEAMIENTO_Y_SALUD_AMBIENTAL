function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5j1Fo6s64pl":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

